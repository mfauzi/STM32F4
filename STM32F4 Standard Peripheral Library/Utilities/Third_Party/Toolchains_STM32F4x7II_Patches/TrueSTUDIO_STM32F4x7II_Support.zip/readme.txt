/******************** (C) COPYRIGHT 2013 STMicroelectronics ********************
* File Name          : readme.txt
* Author             : STMicroelectronics
* Version            : V1.0
* Date               : 18/01/2013
* Description        : This file describes how to add STM32F42x/STM32F43x devices
*                      support for TrueSTUDIO 
********************************************************************************

This package contains the ST-LINK_gdbserver v1.7.2 supporting STM32F42x/STM32F43x devices.
Copy the ST-LINK_gdbserver.exe file into the following path:
[TrueSTUDIO_Install_Dir]\TrueSTUDIO for ARM Pro 3.3.0\Servers\ST-LINK_gdbserver

Note:
======

* The default value of [TrueSTUDIO_Install_Dir] is C:\Program Files\Atollic

* Before installing the files mentioned above, you need to have TrueSTUDIO v3.3.0 
or later installed. 
You can downlaod TrueSTUDIO from Atollic web site @ www.atollic.com

* This patch has been fully tested with TrueSTUDIO v3.3.0 version

******************* (C) COPYRIGHT 2013 STMicroelectronics *****END OF FILE******


