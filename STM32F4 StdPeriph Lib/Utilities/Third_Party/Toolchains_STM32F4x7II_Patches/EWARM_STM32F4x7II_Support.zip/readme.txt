/******************** (C) COPYRIGHT 2013 STMicroelectronics ********************
* File Name          : readme.txt
* Author             : STMicroelectronics
* Version            : V1.0
* Date               : 14-January-2013
* Description        : This file describes how to add STM32F4x7II device
                       support for EWARM 
********************************************************************************

This package contains the needed files to be installed in order to support
STM32F4x7II device by EWARM6.3 and laters.

Running the "EWARM STM32F4x7II_Support" adds the follwing:

1. STM32F4x7II generic connections

2. Automatic STM32F4x7II device flash algorithm selection


Note:
=====
* Before installing the files mentioned above, you need to have EWARM v6.xx 
or later installed. 
You can downlaod EWARM from IAR web site @ www.iar.com

* While running "EWARM STM32F4x7II_Support", the EWARM
install directory is set by default to "C:\Program Files\IAR Systems\Embedded Workbench 6.3\", 
please change it manually if you have EWARM installed at different location.

* To be able to choose your STM32F4x7II device: 
1. Open your project
2. Go to Project> General options > target > Device""
3. Choose, the right part number from the list, "STM32F4x7II".
4. The flash algorithm will be invoked automatically.


* This patch has been fully tested with EWARM v6.3 version

******************* (C) COPYRIGHT 2013 STMicroelectronics *****END OF FILE******


