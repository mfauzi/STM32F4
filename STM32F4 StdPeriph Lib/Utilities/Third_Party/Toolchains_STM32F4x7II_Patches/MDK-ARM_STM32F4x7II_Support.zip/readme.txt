/******************** (C) COPYRIGHT 2013 STMicroelectronics ********************
* File Name          : readme.txt
* Author             : STMicroelectronics
* Version            : V1.0
* Date               : 14-January-2013
* Description        : This file describes how to add STM32F4x7II device
                       support for ARM-MDK v4.xx
********************************************************************************

This package contains the needed files to be installed in order to support
STM32F4x7II device by ARM-MDK v4.xx.

If you already installed a patch for STM32F4x7II device, please:

1. Please run the "MDK-ARM STM32F4x7II Basic_Support.exe" which adds the follwing:

- STM32Fx7II devices Database to the original Generic CPU Database 
that is included with Keil uVision4.

- Automatic STM32F4x7II devices flash algorithm selection

Note:
=====
* Before installing the files mentioned above, you need to have ARM-MDK v4.xx 
or later installed. 
You can downlaod ARM-MDK from keil web site @ www.keil.com

* While running "MDK-ARM STM32F4x7II Basic_Support", the MDK-ARM
install directory is set by default to "C:\keil", please change it manually if you have 
MDK-ARM installed at different location.

* To be able to choose your STM32F4x7II device: 
1. Open your project
2. Go to Project>"options for Target....""
3. The "Options for Target...."window appears
4. Click on Device Tab
5. In the Database dialog you should use the drop down box and select 
"STMicroelectronics STM32F4x7II device" 


******************* (C) COPYRIGHT 2013 STMicroelectronics *****END OF FILE******
